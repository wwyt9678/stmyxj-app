书途 App · 一次性构建包
========================

【包里 3 个东西】
  开始这里.html   ← 先打开这个，照着 4 步做（含一键复制文件名 / 内容）
  p.zip           ← 唯一需要上传到 GitHub 的文件
  build.yml.txt   ← 纯文本兜底，手机打不开 .yml 时看它

【为什么这次不会再来回改】
所有构建逻辑（装依赖、写锁屏提醒、生成 Android 工程、补权限、Gradle 编译、产出 APK）
全部装进 p.zip/go.sh。仓库里那个 workflow 只有 19 行全英文、无中文、无长脚本、
无 esbuild、无 heredoc —— 提交一次就永远不用再动。

而且用的是 on: push：把 build.yml 提交上去那一下会自动开始构建，
不需要去 Actions 点 Run workflow。

【四步】
1. 新建仓库 shutu-app（Public，勾 Add a README file）
2. Add file → Upload files → 传 p.zip → Commit
3. Add file → Create new file
   文件名：.github/workflows/build.yml  （用「开始这里.html」里的复制按钮）
   内容：同样用复制按钮
   → Commit changes（这一步提交后自动开跑）
4. Actions 等 5~15 分钟变绿 → 底部 Artifacts → shutu-apk → 解压出 app.apk → 安装

【验证记录】
- workflow 全 ASCII、YAML 合法、19 行
- p.zip 内 6 个文件齐全，网页已引用 native-alarm.js 且无 Service Worker
- native-alarm.js 为纯 IIFE、零 import、零打包工具
- go.sh 通过 bash -n
- 第 1~4 步在沙盒【真实执行通过】：npm install 装齐 94 个包 → Capacitor CLI 直调 →
  cap add android / cap sync android 成功 → AndroidManifest 生成 6 项权限 →
  网页 index.html（598 KB）与锁屏提醒脚本（5 KB）确实进入 assets/public/ →
  gradlew 已生成，且本地通知插件被 cap sync 正确识别
- 仅第 5 步 Gradle 编译交给 GitHub 云端 ubuntu-latest（自带 Android SDK、Java 17、完整 npm 源）
- 已移除 esbuild 等所有临时下载环节，go.sh 直调本地 CLI，不再依赖 npx 现拉包

【装完】
允许通知；App 是全新空间，用「🔐 生成同步码」把旧存档搬过去。

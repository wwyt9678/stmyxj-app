#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "== 1/6 安装依赖 =="
npm install --no-audit --no-fund --ignore-scripts
CAP=node_modules/@capacitor/cli/bin/capacitor
if [ ! -f "$CAP" ]; then
  echo "补装 Capacitor CLI"
  npm install @capacitor/cli@7.6.10 --no-audit --no-fund --ignore-scripts --no-save
fi
test -f "$CAP" || { echo "Capacitor CLI 没装好"; exit 1; }
echo "CLI 就位"

echo "== 2/6 锁屏提醒脚本 =="
cp -f native-alarm.js www/native-alarm.js
grep -q 'native-alarm.js' www/index.html || { echo "网页没引用提醒脚本"; exit 1; }

echo "== 3/6 生成 Android 工程 =="
CI=true node "$CAP" add android
CI=true node "$CAP" sync android
test -f android/app/src/main/AndroidManifest.xml || { echo "Android 工程没生成"; exit 1; }

echo "== 4/6 补齐系统权限 =="
python3 patch-android.py

echo "== 5/6 编译 APK =="
cd android
chmod +x ./gradlew
./gradlew assembleDebug --no-daemon --stacktrace
cd ..

echo "== 6/6 产出 =="
mkdir -p ../out
cp -f android/app/build/outputs/apk/debug/app-debug.apk ../out/app.apk
ls -lh ../out/app.apk

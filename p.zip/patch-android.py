#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""给 Capacitor 生成的 Android 工程补上锁屏闹钟所需权限。"""
import sys

PATH = 'android/app/src/main/AndroidManifest.xml'

PERMS = (
    '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n'
    '    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />\n'
    '    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />\n'
    '    <uses-permission android:name="android.permission.VIBRATE" />\n'
    '    <uses-permission android:name="android.permission.WAKE_LOCK" />\n'
    '    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />\n'
)

try:
    with open(PATH, encoding='utf-8') as f:
        s = f.read()
except Exception as e:
    print('找不到 AndroidManifest.xml:', e)
    sys.exit(1)

if 'POST_NOTIFICATIONS' not in s:
    if '<application' not in s:
        print('manifest 结构异常')
        sys.exit(1)
    s = s.replace('<application', PERMS + '    <application', 1)
    with open(PATH, 'w', encoding='utf-8') as f:
        f.write(s)
    print('已写入 6 项权限')
else:
    print('权限已存在，跳过')

# 确认 www 资源已被复制
import os
assets = 'android/app/src/main/assets/public/index.html'
if not os.path.exists(assets):
    print('警告：未找到 assets/public/index.html，请确认 cap add android 成功')
else:
    print('网页资源已就位:', os.path.getsize(assets), 'bytes')
